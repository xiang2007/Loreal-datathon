"""
Configuration modules for L'Oréal Comment Analysis
"""